import React from 'react';
import { View, Text, Image, TextInput, StyleSheet, Dimensions } from 'react-native';

const { width } = Dimensions.get('window');

const HeroBanner = () => {
  return (
    <View style={styles.container}>
      <View style={styles.contentContainer}>
        <View style={styles.textContainer}>
          <Text style={styles.title}>Little Lemon</Text>
          <Text style={styles.subtitle}>Chicago</Text>
          <Text style={styles.description}>We are a family owned Mediterranean Restaurant, focused on traditional recipes served with a modern twist</Text>
        </View>
        <Image
          source={require("../img/Hero.png")}
          style={styles.bannerImage}
        />
      </View>
      <View style={styles.searchBar}>
        <TextInput
          style={styles.input}
          placeholder="Search for dishes"
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
    backgroundColor:'#495e57',
  },
  contentContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: width * 0.8,
    marginBottom: 10,
  },
  textContainer: {
    flex: 1,
  },
  bannerImage: {
    width: width * 0.3,
    height: 150,
  },
  title: {
    color: '#F4CE14',
    fontSize: 24,
    fontWeight: 'bold',
    marginTop: 10,
    fontFamily: 'markazi',
  },
  subtitle: {
    color: 'white',
    fontSize: 18,
    marginTop: 5,
    fontFamily: 'markazi',
  },
  description: {
    color: 'white',
    textAlign: 'left',
    marginTop: 10,
    fontFamily: 'Karla',
  },
  searchBar: {
    backgroundColor: '#F2F2F2',
    borderRadius: 10,
    marginTop: 20,
    paddingHorizontal: 10,
    fontFamily: 'karla',
  },
  input: {
    height: 40,
  },
});

export default HeroBanner;
