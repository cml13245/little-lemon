import React from 'react';
import { ScrollView, Text, TouchableOpacity, TextInput, StyleSheet } from 'react-native';

const CategoriesList = ({ selectedCategories, handleCategorySelect, searchText, handleSearchTextChange }) => {
  const categories = ['Starters', 'Mains', 'Desserts', 'Drinks', 'Specials'];

  return (
    <ScrollView contentContainerStyle={styles.menuContainer} horizontal showsHorizontalScrollIndicator={false}>
      {categories.map((category, index) => (
        <TouchableOpacity
          key={index}
          style={[
            styles.categoryButton,
            {
              backgroundColor: selectedCategories.includes(category) ? '#5A87E7' : '#DDDDDD',
            },
          ]}
          onPress={() => handleCategorySelect(category)}
        >
          <Text style={[styles.categoryText, { color: selectedCategories.includes(category) ? 'white' : 'black' }]}>
            {category}
          </Text>
        </TouchableOpacity>
      ))}
      <TextInput
        style={styles.searchBar}
        placeholder="Search for dishes"
        onChangeText={handleSearchTextChange}
        value={searchText}
      />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  menuContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 1,
    marginHorizontal: 1,
  },
  categoryButton: {
    padding: 8,
    borderRadius: 8,
    width: '35%',
    marginRight: '5%',
    height: 40,
  },
  categoryText: {
    textAlign: 'center',
    fontSize: 12,
    fontFamily: 'karla',
    fontWeight: 'bold',
  },
  searchBar: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 8,
    paddingLeft: 10,
    marginTop: 10,
  },
});

export default CategoriesList;
