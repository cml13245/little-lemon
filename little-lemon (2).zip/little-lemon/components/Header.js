import React from 'react';
import { View, Image, TouchableOpacity, StyleSheet } from 'react-native';

const Header = () => {
  return (
    <View style={styles.headerContainer}>
      <View style={styles.logoContainer}>
       <Image source={require("../img/logo.png")} style={styles.logo} resizeMode="contain" />
      </View>
      <TouchableOpacity onPress={() => console.log('Navigate to Profile')}>
        <Image source={require("../img/Avatar.png")} style={styles.avatar} />
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  headerContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 10,
    backgroundColor: '#f9f9f9',
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  logoContainer: {
    flex: 1, // Adjusted to expand the logo container
    alignItems: 'flex-start', // Adjusted alignment to start of the container
  },
  logo: {
    height: 100,
    width: 100,
  },
  avatar: {
    height: 70,
    width: 70,
    borderRadius: 20, 
  },
});

export default Header;
