import React, { useState } from 'react';
import { ScrollView, Text, StyleSheet, TextInput, Pressable, KeyboardAvoidingView, Platform, Keyboard, Dimensions } from 'react-native';

export default function Onboarding({ navigation, onComplete }) {
  const [name, onChangeName] = useState('');
  const [email, onChangeEmail] = useState('');

  const isValidName = (name) => {
    return /^[a-zA-Z]+$/.test(name) && name.length > 0;
  };

  const isValidEmail = (email) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  };

  const handlePress = () => {
    if (!isValidName(name)) {
      alert('Oops! Your name must contain only characters');
      return;
    }

    if (!isValidEmail(email)) {
      alert("Oops! Looks like that's an invalid email");
      return;
    }

    onComplete({ name, email });
  };

  const isIphoneSE = () => {
    const { height, width } = Dimensions.get('window');
    return height === 568 || width === 568;
  };

  const getKeyboardVerticalOffset = () => {
    if (isIphoneSE()) {
      return -250; // Adjusted offset for iPhone SE
    } else {
      return 0;
    }
  };

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      keyboardVerticalOffset={getKeyboardVerticalOffset()}
    >
      <ScrollView contentContainerStyle={styles.scrollContainer} keyboardShouldPersistTaps="handled">
        <Text style={styles.headerText}>Let us get to know you</Text>
        <TextInput
          style={styles.inputBox}
          value={name}
          onChangeText={(text) => onChangeName(text)}
          placeholder={'first name'}
        />
        <TextInput
          style={styles.inputBox}
          value={email}
          onChangeText={(text) => onChangeEmail(text)}
          placeholder={'email'}
          keyboardType={'email-address'}
        />
        <Pressable onPress={handlePress} style={styles.button}>
          <Text style={styles.buttonText}>Next</Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#495e57',
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
  },
  headerText: {
    padding: 40,
    fontSize: 40,
    color: '#EDEFEE',
    textAlign: 'center',
    fontFamily: 'markazi',
  },
  inputBox: {
    padding: 10,
    fontSize: 16,
    borderColor: '#EDEFEE',
    backgroundColor: '#EDEFEE',
    height: 40,
    margin: 12,
    borderWidth: 1,
  },
  button: {
    padding: 10,
    marginVertical: 20,
    marginHorizontal: 100,
    backgroundColor: '#F4CE14',
    borderRadius: 20,
  },
  buttonText: {
    color: '#f5f5f5',
    textAlign: 'center',
    fontSize: 18,
    fontFamily: 'karla',
    fontWeight: 'bold',
  },
});
