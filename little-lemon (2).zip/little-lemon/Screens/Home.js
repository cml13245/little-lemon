import React, { useEffect, useState, useCallback } from 'react';
import { ScrollView, View, Text, FlatList, Image, TouchableOpacity, StyleSheet, SafeAreaView, Platform, Dimensions } from 'react-native';
import * as SQLite from 'expo-sqlite';
import Constants from 'expo-constants';
import CategoriesList from '../components/CategoriesList';
import HeroBanner from '../components/HeroBanner';

const { width, height } = Dimensions.get('window');

const HomeScreen = ({ navigation }) => {
  const [menuData, setMenuData] = useState([]);
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [searchText, setSearchText] = useState('');

  const fetchMenuData = useCallback(async () => {
    const response = await fetch('https://raw.githubusercontent.com/Meta-Mobile-Developer-PC/Working-With-Data-API/main/capstone.json');
    const data = await response.json();
    const transformedData = transformData(data.menu);
    setMenuData(transformedData);

    const db = SQLite.openDatabase('little_lemon');
    db.transaction((tx) => {
      tx.executeSql(
        'create table if not exists menu (id integer primary key not null, name text, description text, image text)'
      );
      transformedData.forEach((item) => {
        tx.executeSql('insert into menu (name, description, image) values (?, ?, ?)', [
          item.name,
          item.description,
          item.image,
        ]);
      });
    });
  }, []);

  useEffect(() => {
    fetchMenuData();
  }, [fetchMenuData]);

  const transformData = (data) => {
    return data.map((item) => ({
      id: item.id,
      name: item.name,
      description: item.description,
      image: `https://github.com/Meta-Mobile-Developer-PC/Working-With-Data-API/blob/main/images/${item.image}?raw=true`,
    }));
  };

  const renderMenuItem = ({ item }) => {
    if (item.name.toLowerCase().includes(searchText.toLowerCase())) {
      return (
        <TouchableOpacity style={styles.menuItemContainer}>
          <Image source={{ uri: item.image }} style={styles.menuItemImage} resizeMode="contain" />
          <View style={styles.menuItemTextContainer}>
            <Text style={styles.menuItemName} numberOfLines={2} ellipsizeMode="tail">
              {' '}
              {item.name}
            </Text>
            <Text style={styles.menuItemDescription} numberOfLines={3} ellipsizeMode="tail">
              {item.description}
            </Text>
          </View>
        </TouchableOpacity>
      );
    }
    return null;
  };

  const keyExtractor = (item) => {
    if (item && item.id) {
      return item.id.toString();
    }
    return '';
  };

  const handleCategorySelect = (category) => {
    if (selectedCategories.includes(category)) {
      setSelectedCategories(selectedCategories.filter((item) => item !== category));
    } else {
      setSelectedCategories([...selectedCategories, category]);
    }
  };

  const handleSearchTextChange = useCallback((text) => {
    setSearchText(text);
  }, []);

  return (
    <SafeAreaView style={styles.container}>
      <HeroBanner />
      <CategoriesList
        selectedCategories={selectedCategories}
        handleCategorySelect={handleCategorySelect}
        searchText={searchText}
        handleSearchTextChange={handleSearchTextChange}
      />
      <FlatList data={menuData} renderItem={renderMenuItem} keyExtractor={keyExtractor} />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    paddingTop: Platform.OS === 'android' ? Constants.statusBarHeight : 0,
  },
  menuItemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    marginBottom: 20,
    width: width * 0.9,
  },
  menuItemImage: {
    width: width * 0.2,
    height: width * 0.2,
    borderRadius: 10,
    marginRight: 10,
  },
  menuItemTextContainer: {
    flex: 1,
    flexWrap: 'wrap',
    justifyContent: 'center',
  },
  menuItemName: {
    fontWeight: 'bold',
    fontSize: height * 0.02,
    maxWidth: width * 0.7,
  },
  menuItemDescription: {
    color: 'gray',
    fontSize: height * 0.018,
    maxWidth: width * 0.7,
  },
});

export default HomeScreen;
