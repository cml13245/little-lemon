import React, { useState } from 'react';
import { ScrollView, Text, StyleSheet, TextInput, View, Switch, TouchableOpacity, Image } from 'react-native';

const Profile = ({ route }) => {
  const { name, email } = route.params;
  const [firstName, setFirstName] = useState(name);
  const [lastName, setLastName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');

  const [orderStatuses, setOrderStatuses] = useState(false);
  const [passwordChanges, setPasswordChanges] = useState(false);
  const [specialOffers, setSpecialOffers] = useState(false);
  const [newsletter, setNewsletter] = useState(false);

  const [avatar, setAvatar] = useState(null);

  const handleAvatarChange = (image) => {
    setAvatar(image);
  };

  const handleAvatarRemove = () => {
    setAvatar(null);
  };

  const generateInitials = () => {
    const firstInitial = firstName ? firstName[0] : '';
    const lastInitial = lastName ? lastName[0] : '';
    return `${firstInitial}${lastInitial}`;
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.headerText}>Personal Information</Text>
      <View style={styles.avatarContainer}>
        {avatar ? (
          <Image source={{ uri: avatar }} style={styles.avatar} />
        ) : (
          <View style={styles.avatarPlaceholder}>
            <Text style={styles.avatarInitials}>{generateInitials()}</Text>
          </View>
        )}
        <View style={styles.avatarButtonsContainer}>
          <TouchableOpacity style={styles.avatarButton} onPress={() => handleAvatarChange('YOUR_IMAGE_URI')}>
            <Text style={styles.avatarButtonText}>Change</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.avatarButton} onPress={handleAvatarRemove}>
            <Text style={styles.avatarButtonText}>Remove</Text>
          </TouchableOpacity>
        </View>
      </View>
      <View style={styles.container}>
        <Text style={styles.headerText}>User Profile</Text>
        <TextInput
          style={styles.inputBox}
          value={firstName}
          onChangeText={setFirstName}
          placeholder={'First Name'}
        />
        <TextInput
          style={styles.inputBox}
          value={lastName}
          onChangeText={setLastName}
          placeholder={'Last Name'}
        />
        <TextInput
          style={styles.inputBox}
          value={email}
          editable={false}
          placeholder={'Email Address'}
        />
        <TextInput
          style={styles.inputBox}
          value={phoneNumber}
          onChangeText={setPhoneNumber}
          placeholder={'Phone Number'}
          keyboardType={'phone-pad'}
        />
        <Text style={styles.notificationHeader}>Email Notifications</Text>
        <View style={styles.notificationContainer}>
          <View style={styles.notificationItem}>
            <Text>Order Statuses</Text>
            <Switch value={orderStatuses} onValueChange={setOrderStatuses} />
          </View>
          <View style={styles.notificationItem}>
            <Text>Password Changes</Text>
            <Switch value={passwordChanges} onValueChange={setPasswordChanges} />
          </View>
          <View style={styles.notificationItem}>
            <Text>Special Offers</Text>
            <Switch value={specialOffers} onValueChange={setSpecialOffers} />
          </View>
          <View style={styles.notificationItem}>
            <Text>Newsletter</Text>
            <Switch value={newsletter} onValueChange={setNewsletter} />
          </View>
        </View>
      </View>
      <View style={styles.buttonContainer}>
      <View style={styles.buttonGroup}>
        <TouchableOpacity style={styles.button} onPress={() => console.log("Save Changes")}>
          <Text style={styles.buttonText}>Save Changes</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => console.log("Discard Changes")}>
          <Text style={styles.buttonText}>Discard Changes</Text>
        </TouchableOpacity>
        </View>
        <TouchableOpacity style={styles.button} onPress={() => console.log("Log Out")}>
          <Text style={styles.buttonText}>Log Out</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#495e57',
  },
  headerText: {
    padding: 20,
    fontSize: 25,
    color: '#EDEFEE',
    textAlign: 'center',
    fontFamily: 'markazi',
  },
  avatarContainer: {
    alignItems: 'center',
    marginTop: 20,
  },
  avatar: {
    width: 150,
    height: 150,
    borderRadius: 75,
  },
  avatarPlaceholder: {
    width: 150,
    height: 150,
    borderRadius: 75,
    backgroundColor: '#EDEFEE',
    alignItems: 'center',
    justifyContent: 'center',
  },
  avatarButtonsContainer: {
    flexDirection: 'row',
    marginTop: 10,
  },
  avatarButton: {
    marginHorizontal: 20,
    backgroundColor: '#F4CE14',
    padding: 10,
    borderRadius: 5,
  },
  avatarButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  inputBox: {
    padding: 10,
    fontSize: 16,
    borderColor: '#EDEFEE',
    backgroundColor: '#EDEFEE',
    height: 40,
    margin: 12,
    borderWidth: 1,
  },
  notificationHeader: {
    marginTop: 30,
    marginBottom: 10,
    fontSize: 20,
    color: '#EDEFEE',
    textAlign: 'center',
    fontFamily: 'markazi',
  },
  notificationContainer: {
    backgroundColor: '#EDEFEE',
    padding: 10,
    borderRadius: 5,
    marginHorizontal: 20,
  },
  notificationItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#495e57',
  },
  avatarInitials: {
    fontSize: 40,
    color: '#495e57',
    textAlign: 'center',
    fontFamily: 'markazi',
  },
  buttonContainer: {
    alignItems: 'center',
    marginVertical: 20,
  },
  buttonGroup: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
    marginHorizontal: 20,
  },
  button: {
    backgroundColor: '#F4CE14',
    padding: 10,
    borderRadius: 8,
    width: '45%',
    marginRight: '5%',
  },
  buttonText: {
    color: '#fff',
    textAlign: 'center',
    fontSize: 12,
    fontFamily: 'karla',
    fontWeight: 'bold',
  },
});

export default Profile;