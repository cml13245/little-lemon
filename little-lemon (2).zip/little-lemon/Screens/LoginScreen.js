import React, { useState } from 'react';
import { ScrollView, Text, StyleSheet, TextInput, Pressable, KeyboardAvoidingView, Platform } from 'react-native';

export default function LoginScreen({ navigation }) {
  const [email, onChangeEmail] = useState('');
  const [password, onChangePassword] = useState('');

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <ScrollView>
        <Text style={styles.headerText}>Welcome to Little Lemon</Text>
        <Text style={styles.regularText}>Login to continue</Text>
        <TextInput
          style={styles.inputBox}
          value={email}
          onChangeText={onChangeEmail}
          placeholder={'email'}
          keyboardType={'email-address'}
        />
        <TextInput
          style={styles.inputBox}
          value={password}
          onChangeText={onChangePassword}
          placeholder={'password'}
          secureTextEntry={true}
        />
        <Pressable onPress={() => navigation.navigate('Welcome')} style={styles.button}>
          <Text style={styles.buttonText}>Log In</Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#495e57',
  },
  headerText: {
    padding: 40,
    fontSize: 40,
    color: '#EDEFEE',
    textAlign: 'center',
    fontFamily: 'markazi'
  },
  inputBox: {
    padding: 10,
    fontSize: 16,
    borderColor: '#EDEFEE',
    backgroundColor: '#EDEFEE',
    height: 40,
    margin: 12,
    borderWidth: 1,
  },
  button: {
    padding: 10,
    marginVertical: 20,
    marginHorizontal: 100,
    backgroundColor: '#F4CE14',
    borderRadius: 20,
  },
  buttonText: {
    color: '#f5f5f5',
    textAlign: 'center',
    fontSize: 18,
    fontFamily: 'karla',
    fontWeight: 'bold',
  },
});
