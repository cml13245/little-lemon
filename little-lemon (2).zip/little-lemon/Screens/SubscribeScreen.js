import React, { useState } from 'react';
import { ScrollView, Text, StyleSheet, TextInput, Pressable, KeyboardAvoidingView, Platform, Image, Alert } from 'react-native';

export default function SubscribeScreen() {
  const [email, onChangeEmail] = useState('');

  const handleSubscribe = () => {
    Alert.alert(
      'Congrats!',
      'You have subscribed',
      [{ text: 'Great!', onPress: () => console.log('alert closed') }]
    );
  };

  return (
    <KeyboardAvoidingView style={styles.container} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <Image
          style={styles.image}
          source={require("../img/logo.png")}
          resizeMode="contain"
          accessible={true}
          accessibilityLabel={'Little Lemon Logo'}
        />

        <Text style={styles.headerText}>Subscribe to our newsletter for our latest delicious recipes!</Text>
        <Text style={styles.regularText}>Enter your email below to continue</Text>
        <TextInput
          style={styles.inputBox}
          value={email}
          onChangeText={onChangeEmail}
          placeholder={'email'}
          keyboardType={'email-address'}
        />
        <Pressable onPress={handleSubscribe} style={styles.button}>
          <Text style={styles.buttonText}>Subscribe</Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#495E57',
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: 'center',
  },
  headerText: {
    padding: 40,
    fontSize: 40,
    color: '#EDEFEE',
    textAlign: 'center',
    fontFamily: 'markazi'
  },
  inputBox: {
    padding: 10,
    fontSize: 16,
    borderColor: '#EDEFEE',
    backgroundColor: '#EDEFEE',
    height: 40,
    margin: 12,
    borderWidth: 1,
  },
  button: {
    padding: 10,
    marginVertical: 20,
    marginHorizontal: 100,
    backgroundColor: '#F4CE14',
    borderRadius: 20,
  },
  buttonText: {
    color: '#f5f5f5',
    textAlign: 'center',
    fontSize: 18,
    fontFamily: 'karla',
    fontWeight: 'bold',
  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 10,
    alignSelf: 'center',
    marginVertical: 20,
  },
});