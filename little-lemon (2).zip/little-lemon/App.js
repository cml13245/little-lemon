import React, { useState } from 'react';
import { StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Header from './components/Header';
import LittleLemonFooter from './components/LittleLemonFooter';
import Onboarding from './Screens/Onboarding';
import Profile from './Screens/Profile';
import Home from './Screens/Home';
import CategoriesList from './components/CategoriesList';
import HeroBanner from './components/HeroBanner';

const Tab = createBottomTabNavigator();

const App = () => {
  const [isSignedIn, setIsSignedIn] = useState(false);
  const [userData, setUserData] = useState({ name: '', email: '' });

  const handleOnboardingCompletion = (data) => {
    setUserData(data);
    setIsSignedIn(true);
  };

 return (
  <NavigationContainer>
    <Tab.Navigator
      initialRouteName={isSignedIn ? 'Profile' : 'Onboarding'} // Set initialRouteName to 'Profile' if the user is signed in
      screenOptions={{
        header: (props) => <Header {...props} />,
        footer: (props) => <LittleLemonFooter {...props} />,
      }}
    >
      {isSignedIn ? (
        <>
          <Tab.Screen name="Home" component={Home} />
          <Tab.Screen name="Profile" component={Profile} initialParams={userData} />
        </>
      ) : (
        <Tab.Screen name="Onboarding">
          {(props) => <Onboarding {...props} onComplete={handleOnboardingCompletion} />}
        </Tab.Screen>
      )}
    </Tab.Navigator>
  </NavigationContainer>
);

};

const drawerContentOptions = {
  activeTintColor: '#ffffff',
  activeBackgroundColor: '#495e57',
  inactiveTintColor: '#000000',
  labelStyle: {
    fontSize: 16,
    fontFamily: 'karla',
  },
};

const drawerStyle = {
  backgroundColor: '#EE9972',
  width: 240,
};

export default App;
